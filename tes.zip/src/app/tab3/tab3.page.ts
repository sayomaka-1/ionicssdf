import { Component } from "@angular/core";
import { FirebaseAnalytics } from "@ionic-native/firebase-analytics/ngx";

@Component({
  selector: "app-tab3",
  templateUrl: "tab3.page.html",
  styleUrls: ["tab3.page.scss"]
})
export class Tab3Page {
  constructor(private firebaseAnalytics: FirebaseAnalytics) {}

  ionViewDidEnter() {
    console.log("ionViewDidEnter");
    this.firebaseAnalytics.setCurrentScreen("tab 3");
    console.log("tab 3");
  }

  redeem() {
    console.log("Redeemed");
    this.firebaseAnalytics
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"redeem",VALUE:5})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
  Transfer() {
    console.log("Transfer");
    this.firebaseAnalytics
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"transfer",VALUE:10})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
  Scan() {
    console.log("Scan");
    this.firebaseAnalytics
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"scan",VALUE:15})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
  Sample() {
    console.log("sample");
    this.firebaseAnalytics
      .logEvent("REDEEM_COIN",{REDEEM_TYPE:"sample",VALUE: 20})
      .then((res: any) => console.log(res))
      .catch((error: any) => console.error(error));
  }
}
